TERMUX_PKG_HOMEPAGE=http://www.thekelleys.org.uk/dnsmasq/doc.html
TERMUX_PKG_DESCRIPTION="Dnsmasq provides network infrastructure for small networks"
TERMUX_PKG_LICENSE="GPL-3.0"
TERMUX_PKG_VERSION=2.80
TERMUX_PKG_SRCURL=http://www.thekelleys.org.uk/dnsmasq/dnsmasq-${TERMUX_PKG_VERSION}.tar.xz
TERMUX_PKG_SHA256=cdaba2785e92665cf090646cba6f94812760b9d7d8c8d0cfb07ac819377a63bb
TERMUX_PKG_BUILD_IN_SRC=YES
