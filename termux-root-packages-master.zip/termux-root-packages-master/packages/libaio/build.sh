TERMUX_PKG_HOMEPAGE=http://lse.sourceforge.net/io/aio.html
TERMUX_PKG_DESCRIPTION="Linux kernel AIO access library"
TERMUX_PKG_LICENSE="LGPL-2.1"
TERMUX_PKG_VERSION=0.3.111
TERMUX_PKG_SRCURL=http://ftp.de.debian.org/debian/pool/main/liba/libaio/libaio_${TERMUX_PKG_VERSION}.orig.tar.gz
TERMUX_PKG_SHA256=62cf871ad8fd09eb3418f00aca7a7d449299b8e1de31c65f28bf6a2ef1fa502a
TERMUX_PKG_BUILD_IN_SRC=yes
