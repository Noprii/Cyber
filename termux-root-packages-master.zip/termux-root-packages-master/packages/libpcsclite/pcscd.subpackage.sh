TERMUX_SUBPKG_DESCRIPTION="Middleware to access a smart card using SCard API (PC/SC). (daemon side)"
TERMUX_SUBPKG_INCLUDE="bin/pcscd share/man/man5/reader.conf.5.gz share/man/man8/pcscd.8.gz"
